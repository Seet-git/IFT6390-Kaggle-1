import torch
import torch.nn as nn
import pandas as pd
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import f1_score
import numpy as np

# Remplacez X_train et y_train par vos données chargées
# Exemple fictif pour illustration
X_train = np.load('../../data/data_train.npy', allow_pickle=True)
y_train = pd.read_csv('../../data/label_train.csv').to_numpy()[:, 1]
# Configuration des tenseurs
X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train, dtype=torch.float32)

# Création du DataLoader sans équilibrage
train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
train_loader = DataLoader(train_dataset, batch_size=10, shuffle=True)


# Définition du modèle de réseau de neurones
class AdvancedNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(AdvancedNN, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.5)
        self.fc2 = nn.Linear(hidden_size, hidden_size // 2)
        self.fc3 = nn.Linear(hidden_size // 2, output_size)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.dropout(x)
        x = self.fc2(x)
        x = self.relu(x)
        x = self.fc3(x)
        return self.sigmoid(x)


# Initialisation des paramètres du modèle
input_size = X_train.shape[1]  # Nombre de caractéristiques dans votre BoW
hidden_size = 128
output_size = 1  # Classification binaire

model = AdvancedNN(input_size, hidden_size, output_size)

# Critère de perte sans pondération
criterion = nn.BCELoss()

# Optimiseur
optimizer = optim.Adam(model.parameters(), lr=0.0001)

# Entraînement du modèle
num_epochs = 1
for epoch in range(num_epochs):
    model.train()  # Assurez-vous que le modèle est en mode entraînement
    running_loss = 0.0
    for inputs, labels in train_loader:
        optimizer.zero_grad()  # Remise à zéro des gradients
        outputs = model(inputs)  # Forward pass
        loss = criterion(outputs.squeeze(), labels)  # Calcul de la perte
        loss.backward()  # Backward pass
        optimizer.step()  # Optimisation

        running_loss += loss.item()

    print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {running_loss / len(train_loader):.4f}')

# Évaluation du modèle
model.eval()  # Passage en mode évaluation
y_pred = []
y_true = []

with torch.no_grad():
    for inputs, labels in train_loader:  # Utilisez un DataLoader de validation pour évaluer
        outputs = model(inputs)
        predicted = (outputs.squeeze() > 0.5).float()
        y_pred.extend(predicted.numpy())
        y_true.extend(labels.numpy())

# Calcul du F1-score
f1 = f1_score(y_true, y_pred)
print(f'F1 Score: {f1:.4f}')
