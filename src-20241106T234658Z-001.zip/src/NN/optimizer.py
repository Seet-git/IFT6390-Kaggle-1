import pandas as pd
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import f1_score

import optuna

import wandb

from src.NN.models import *
from src.NN.utils import *
from src.Naives_bayes.preprocessing import remove_low_frequency_v2

from datetime import datetime

current_time = datetime.now().strftime("%m/%d-%H:%M:%S")


def compute_loss(model, data):
    total_loss = 0.0
    # Mini-Batch
    for inputs, labels in data:
        # Model prediction
        pred = model.forward(inputs)

        # Compute loss
        loss = model.criterion(pred.view(-1), labels.view(-1))
        total_loss += loss.item()

    return total_loss / len(data)


def infer(model, data, threshold: float):
    # Évaluation du modèle
    model.eval()
    y_pred = []
    y_true = []

    with torch.no_grad():
        for inputs, labels in data:
            # Compute the prediction
            outputs = model(inputs)

            # Compute prediction
            pred = (torch.sigmoid(outputs).view(-1) > threshold).float()

            # Add prediction
            y_pred.extend(pred.cpu().numpy())
            y_true.extend(labels.cpu().numpy())

    # Calcul du F1-score
    return f1_score(y_true, y_pred, average="macro")


def fit(model, train_loader, test_loader, epochs, threshold):
    # Loop on all epochs
    for epoch in range(epochs):
        model.train()

        # Mini-Batch
        for inputs, labels in train_loader:
            # Reset backward
            model.optimizer.zero_grad()

            # Model prediction
            pred = model.forward(inputs)

            # Compute loss
            loss = model.criterion(pred.view(-1), labels.view(-1))

            # Backpropagation
            loss.backward()

            # Change weights
            model.optimizer.step()

        # Compute loss
        train_loss = compute_loss(model, train_loader)
        test_loss = compute_loss(model, test_loader)

        # F1 score
        f1_score_train = infer(model, train_loader, threshold)
        f1_score_test = infer(model, test_loader, threshold)

        wandb.log({
            "Epoch": epoch + 1,
            "Train loss": train_loss,
            "Test loss": test_loss,
            "Train F1-score": f1_score_train,
            "Test F1-score": f1_score_test
        })


def split_dataset(inputs_train: np.array, labels_train: np.array):
    """
    Split the dataset into training and test set
    :param inputs_train:
    :param labels_train:
    :return:
    """
    # Shuffle the dataset
    indices = np.arange(len(inputs_train))
    np.random.shuffle(indices)

    inputs_shuffled = inputs_train[indices]
    labels_shuffled = labels_train[indices]

    # Get the size of the training set
    # train_size = int(np.ceil(0.8 * len(inputs_train)))
    train_size = len(inputs_train) - 2355

    # Train set
    set_train_inputs = inputs_shuffled[0:train_size, :]
    set_train_labels = labels_shuffled[0:train_size]

    # Test set
    set_test_inputs = inputs_shuffled[train_size:, :]
    set_test_labels = labels_shuffled[train_size:]

    return set_train_inputs, set_train_labels, set_test_inputs, set_test_labels


def evaluation(inputs_documents: torch.Tensor, labels_documents: torch.Tensor, batch_size=128, hidden_layer=256,
               learning_rate=0.0001, weight_decay=0.01, epochs=10, threshold=0.5,
               minority_weight=4.0, optimizer='Adam', balanced=True) -> float:
    # Define model
    model = MLPClassifier(inputs_documents.shape[1], hidden_layer)

    # Loss function
    class_0_count = (labels_documents == 0).sum().item()
    class_1_count = labels_documents.sum().item()
    value = torch.tensor([(class_0_count / class_1_count) - minority_weight], dtype=torch.float32)
    weight = torch.maximum(torch.tensor(1), value)
    model.criterion = nn.BCEWithLogitsLoss(pos_weight=weight)

    # Set optimizer
    optimizers = {
        'Adam': optim.Adam,
        'SGD': optim.SGD,
        'RMSprop': optim.RMSprop,
        'Adagrad': optim.Adagrad,
        'Adadelta': optim.Adadelta,
        'Nadam': optim.NAdam
    }
    model.optimizer = optimizers[optimizer](model.parameters(), lr=learning_rate, weight_decay=weight_decay)

    # Split dataset to train and test
    inputs_train, labels_train, inputs_test, labels_test = split_dataset(inputs_documents, labels_documents)

    # Train dataset
    train_dataset = TensorDataset(inputs_train, labels_train)

    # Balanced dataset
    if balanced:
        sampler = create_balanced_sampler(labels_train)
        train_loader = DataLoader(train_dataset, batch_size=batch_size, sampler=sampler)
    else:
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

    # Test dataset
    test_dataset = TensorDataset(inputs_test, labels_test)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=True)

    # Entraînement
    fit(model, train_loader, test_loader, epochs, threshold)

    # F1 score
    f1_score_test = infer(model, test_loader, threshold)
    return f1_score_test


def bayesian_optimization(trial):
    batch_size = trial.suggest_int("batch_size", 32, 256, step=32)
    hidden_layer = trial.suggest_int("hidden_layer", 64, 512, step=64)
    learning_rate = trial.suggest_float("learning_rate", 1e-5, 1e-1, log=True)
    weight_decay = trial.suggest_float("weight_decay", 1e-5, 1e-2, log=True)
    epochs = trial.suggest_int("epochs", 5, 50)
    threshold = trial.suggest_float("threshold", 0.1, 0.9)
    minority_weight = trial.suggest_float("minority_weight", 1.0, 5.0)
    optimizer = trial.suggest_categorical("optimizer", ["Adam", "SGD"])
    balanced = trial.suggest_categorical("balanced", [True, False])

    wandb.init(project="MLP Optimizer", name=f"{current_time} - Trial_{trial.number}", config={
        "batch_size": batch_size,
        "hidden_layer": hidden_layer,
        "learning_rate": learning_rate,
        "weight_decay": weight_decay,
        "epochs": epochs,
        "threshold": threshold,
        "minority_weight": minority_weight,
        "optimizer": optimizer,
        "balanced": balanced
    })

    score = evaluation(
        x_tensor, y_tensor,
        batch_size=batch_size,
        hidden_layer=hidden_layer,
        learning_rate=learning_rate,
        weight_decay=weight_decay,
        epochs=epochs,
        threshold=threshold,
        minority_weight=minority_weight,
        optimizer=optimizer,
        balanced=balanced
    )
    return score


if __name__ == '__main__':
    set_seed(1)
    inputs_documents = np.load('../../data/data_train.npy', allow_pickle=True)
    labels_documents = pd.read_csv('../../data/label_train.csv').to_numpy()[:, 1]
    test_documents = np.load('../../data/data_test.npy', allow_pickle=True)

    inputs_documents, test_documents = remove_low_frequency_v2(inputs_documents, test_documents, labels_documents,
                                                               threshold=0)
    x_tensor = torch.tensor(inputs_documents, dtype=torch.float32)
    y_tensor = torch.tensor(labels_documents, dtype=torch.float32)

    # storage_url = "mysql+pymysql://optuna_seet:%40g3NYkke%2AeAFRs@localhost/optuna_MLP"
    storage_url = "mysql+pymysql://optuna_seet:%40g3NYkke%2AeAFRs@6.tcp.ngrok.io:16522/optuna_MLP"


    # Bayesian optimization
    study = optuna.create_study(
        direction="maximize",
        storage = storage_url,  # Specify the storage URL here.
        study_name = f"MLP Optimizer - {current_time}"
    )
    study.optimize(bayesian_optimization, n_trials=50)

    print("Best trial:")
    trial = study.best_trial
    print(f"\tValue: {trial.value}")
    print("\tParams:")
    for key, value in trial.params.items():
        print(f"{key}: {value}")

    wandb.finish()
