import src.config as config
from src.Naives_bayes.training_and_saving import save_prediction
from src.Naives_bayes.optimizer import optimize
import numpy as np
import pandas as pd