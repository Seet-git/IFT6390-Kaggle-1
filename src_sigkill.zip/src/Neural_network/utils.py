import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import precision_recall_curve
import src.config as config
import random
from sklearn.metrics import roc_curve, auc, precision_recall_curve, confusion_matrix, f1_score, precision_score, recall_score, accuracy_score
import seaborn as sns

from torch.utils.data import WeightedRandomSampler

from src.Neural_network.models import *


def set_seed(seed: int):
    """
    Ensures that the experiment is reproducible
    :param seed: seed number
    """
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def plot_precision_recall_curve(model, data, plot=False):
    y_true, y_pred_proba = [], []

    # Récupération des probabilités pour chaque exemple
    model.eval()
    with torch.no_grad():
        for inputs, labels in data:
            outputs = model(inputs)
            y_pred_proba.extend(torch.sigmoid(outputs).view(-1).cpu().numpy())
            y_true.extend(labels.cpu().numpy())

    # Calcul de la courbe PRC
    precision, recall, thresholds = precision_recall_curve(y_true, y_pred_proba)
    f1_scores = 2 * (precision * recall) / (precision + recall) + 0.0001

    # Plot
    if plot:
        plt.figure(figsize=(10, 6))
        plt.plot(recall, precision, label="PRC Curve")
        plt.xlabel("Recall")
        plt.ylabel("Precision")
        plt.title("Precision-Recall Curve")
        plt.legend()
        plt.grid(True)
        plt.show()

    # Meilleur seuil pour le F1-score
    best_threshold = thresholds[np.argmax(f1_scores)]

    return best_threshold


def create_balanced_sampler(y_train):
    # Count class
    class_counts = [(y_train == 0).sum().item(), y_train.sum().item()]

    weights = 1 / torch.tensor(class_counts, dtype=torch.float, device=y_train.device)

    y_train = y_train.to(weights.device)

    sample_weights = weights[y_train.long()]
    sampler = WeightedRandomSampler(weights=sample_weights, num_samples=len(sample_weights), replacement=True)
    return sampler

def get_model(input_size ,hp):
    if input_size <= 0:
        raise ValueError(f"Invalid input_size: {input_size}. It must be positive.")
    if config.ALGORITHM == "MLP_H2":
        return MLP_H2(input_size, hp.hidden_layer1, hp.hidden_layer2, hp.dropout_rate)
    elif config.ALGORITHM == "MLP_H1":
        return MLP_H1(input_size, hp.hidden_layer, hp.dropout_rate)
    elif config.ALGORITHM == "Perceptron":
        return Perceptron(input_size)
    else:
        raise ValueError("Bad ALGORITHM value")


def plot_all_visualizations(y_true, y_scores, y_pred):
    # 1. Courbe ROC
    fpr, tpr, thresholds = roc_curve(y_true, y_scores)
    roc_auc = auc(fpr, tpr)
    plt.figure(figsize=(10, 6))
    plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (AUC = {roc_auc:.2f})')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curve')
    plt.legend(loc="lower right")
    plt.show()

    # 2. Courbe de Précision-Rappel
    precision, recall, _ = precision_recall_curve(y_true, y_scores)
    plt.figure(figsize=(10, 6))
    plt.plot(recall, precision, marker='.', color='b')
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall Curve')
    plt.show()

    # 3. Matrice de Confusion
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.title('Confusion Matrix')
    plt.show()

    # 4. Bar Plot des Métriques
    f1 = f1_score(y_true, y_pred, average="macro")
    precision = precision_score(y_true, y_pred, average="macro", zero_division=0)
    recall = recall_score(y_true, y_pred, average="macro", zero_division=0)
    accuracy = accuracy_score(y_true, y_pred)
    metrics = ['Precision', 'Recall', 'F1-score', 'Accuracy']
    values = [precision, recall, f1, accuracy]
    plt.figure(figsize=(10, 6))
    plt.bar(metrics, values, color=['blue', 'orange', 'green', 'red'])
    plt.xlabel('Metrics')
    plt.ylabel('Scores')
    plt.title('Model Performance Metrics')
    plt.ylim(0, 1)  # Assume metrics are between 0 and 1
    plt.show()
