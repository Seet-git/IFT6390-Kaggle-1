from wordcloud import WordCloud
import matplotlib.pyplot as plt
import numpy as np

def generate_word_cloud(inputs_documents, vocab, output_path='wordcloud.svg'):
    """
    Génère et sauvegarde un Word Cloud basé sur les occurrences de mots dans inputs_documents.

    :param inputs_documents: Tableau contenant les occurrences de mots.
    :param vocab: Liste ou tableau contenant le vocabulaire correspondant.
    :param output_path: Chemin du fichier SVG de sortie.
    """
    # Calcul des fréquences des mots
    word_frequencies = np.sum(inputs_documents, axis=0)

    # Création d'un dictionnaire de mots avec leurs fréquences
    word_freq_dict = {word: freq for word, freq in zip(vocab, word_frequencies)}

    # Génération du Word Cloud
    wordcloud = WordCloud(width=800, height=400, background_color='white').generate_from_frequencies(word_freq_dict)

    # Affichage et sauvegarde du Word Cloud
    plt.figure(figsize=(10, 5))
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis('off')  # Supprime les axes pour un affichage propre
    plt.title("Word Cloud")
    plt.savefig(output_path, format='svg')  # Sauvegarde en format SVG
    plt.show()

# Exemple d'utilisation dans votre fichier
if __name__ == "__main__":
    data_path = "../../data/"
    # Remplacez ces exemples par vos données réelles
    inputs_documents = np.load(f'{data_path}data_train.npy', allow_pickle=True)  # Exemple de tableau d'occurrences
    vocab = np.load(f'{data_path}vocab_map.npy', allow_pickle=True) # Exemple de vocabulaire

    generate_word_cloud(inputs_documents, vocab)
